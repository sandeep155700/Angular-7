﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asset.ResourceReleaseManagement.APIServices.Model;
using Asset.ResourceReleaseManagement.APIServices.Repositories;
using Microsoft.Extensions.Configuration;

namespace Asset.ResourceReleaseManagement.APIServices.BussinessObject
{
    public class Employee_BO
    {
        EmployeeRepository objEmpRepository;
        IEmployeeRepository employeeRepository;
        IConfiguration configuration;

        public Employee_BO(IEmployeeRepository _employeeRepository)
        {
            employeeRepository = _employeeRepository;
        }
        public List<AuthenticateUser> ChkFirstTimelogin(string userName)
        {
            try
            {
                return employeeRepository.ChkFirstTimelogin(userName);
            }
            catch
            {
                throw;
            }
        }
        public Boolean AuthenticateUser(string userName, string password)
        {
            try
            {
                return employeeRepository.AuthenticateUser(userName, password);
            }
            catch
            {
                throw;
            }
        }
        public int SetNewPassword(string userId, string userName, string password)
        {
            try
            {
                return employeeRepository.SetNewPassword(userId, userName, password);
            }
            catch
            {
                throw;
            }
        }
        public string GetLoggedInUserId(string userName)
        {
            try
            {
                return employeeRepository.GetLoggedInUserId(userName);
            }
            catch
            {
                throw;
            }
        }
        public List<UserDetails> GetLoggedInUserDetails(string userName)
        {
            try
            {
                return employeeRepository.GetLoggedInUserDetails(userName);
            }
            catch
            {
                throw;
            }
        }
        public List<ApacRRMMU> GetMUList(string userId)
        {
            try
            {
                return employeeRepository.GetMUList(userId);
            }
            catch 
            {
                throw;
            }
        }
        public List<ApacRRMAccount> GetAccountsList(string muid, string userId)
        {
            try
            {
                return employeeRepository.GetAccountsList(muid, userId);
            }
            catch
            {
                throw;
            }
        }
        public List<ApacRRMProjectDetails> GetProjectsList(string muid, string accountid, string userId)
        {
            try
            {
                return employeeRepository.GetProjectsList(muid, accountid, userId);
            }
            catch
            {
                throw;
            }
        }
        public List<EmployeeTaggingDetails> GetEmployeeTaggingDetailsList(string userId)
        {
            try
            {
                return employeeRepository.GetEmployeeTaggingDetailsList(userId);
            }
            catch
            {
                throw;
            }
        }
        public List<EmployeeDetailsPM> GetProjectResourceDetailsList(string muid, string accountid, string projectcodes, string userId)
        {
            try
            {
                return employeeRepository.GetProjectResourceDetailsList(muid, accountid, projectcodes, userId);
            }
            catch
            {
                throw;
            }
        }
        public int InsertUpdateResourceDetailsPM(EmployeeDetailsPM employeeDetailsPM, string userId)
        {
            try
            {
                return employeeRepository.InsertUpdateResourceDetailsPM(employeeDetailsPM, userId);
            }
            catch
            {
                throw;
            }
        }
        public List<EmployeeDetailsRMG> GetEmployeesListForRMG(string userId)
        {
            try
            {
                return employeeRepository.GetEmployeesListForRMG(userId);
            }
            catch
            {
                throw;
            }
        }
        public int UpdateResourceDetailsRMG(EmployeeDetailsRMG employeeDetailsRMG, string userId)
        {
            try
            {
                return employeeRepository.UpdateResourceDetailsRMG(employeeDetailsRMG, userId);
            }
            catch
            {
                throw;
            }
        }

    }
}
