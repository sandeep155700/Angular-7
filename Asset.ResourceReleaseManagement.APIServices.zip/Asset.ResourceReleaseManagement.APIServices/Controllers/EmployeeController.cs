﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asset.ResourceReleaseManagement.APIServices.Repositories;
using Asset.ResourceReleaseManagement.APIServices.Model;
using Asset.ResourceReleaseManagement.APIServices.BussinessObject;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Text.RegularExpressions;
using Asset.ResourceReleaseManagement.APIServices.ExceptionHandling;

namespace Asset.ResourceReleaseManagement.APIServices.Controllers
{
    [Produces("application/json")]
    [ApiController]
    [EnableCors("AllowMyOrigin")]
    public class EmployeeController : Controller
    {
        EmployeeRepository objEmpRepository;
        IEmployeeRepository employeeRepository;
        Employee_BO employee_BO;
        public EmployeeController(IEmployeeRepository _employeeRepository)
        {
            employeeRepository = _employeeRepository;
            employee_BO = new Employee_BO(employeeRepository);
        }

        [HttpGet]
        [Route("api/GetFirstTimelogin/{userName}")]
        [EnableCors("AllowMyOrigin")]
        public List<AuthenticateUser> ChkFirstTimelogin(string userName)
        {
            var result = new List<AuthenticateUser>();
            try
            {
                result = employee_BO.ChkFirstTimelogin(userName);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetAuthenticateUser/{userName}/{password}")]
        [EnableCors("AllowMyOrigin")]
        public Boolean AuthenticateUser(string userName, string password)
        {
            var result = false;
            try
            {
                result = employee_BO.AuthenticateUser(userName, password);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/UpdateNewPassword/{userId}/{userName}/{password}")]
        [EnableCors("AllowMyOrigin")]
        public int SetNewPassword(string userId, string userName, string password)
        {
            var result = 0;
            try
            {
                result = employee_BO.SetNewPassword(userId, userName, password);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetLoggedinUserRole/{username}")]
        [EnableCors("AllowMyOrigin")]
        public List<UserDetails> GetLoggedInUserDetails(string username)
        {
            var result = new List<UserDetails>();
            try
            {
                result = employee_BO.GetLoggedInUserDetails(username);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetMUList")]
        [EnableCors("AllowMyOrigin")]
        public List<ApacRRMMU> GetMUList([FromHeader]string Authorization)
        {
            var result = new List<ApacRRMMU>();
            try
            {
                result = employee_BO.GetMUList(Authorization);               
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetAccountsList/{muid}")]
        [EnableCors("AllowMyOrigin")]
        public List<ApacRRMAccount> GetAccountsList(string muid, [FromHeader]string Authorization)
        {
            var result = new List<ApacRRMAccount>();
            try
            {
                result = employee_BO.GetAccountsList(muid, Authorization);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetProjectsList/{muid}/{accountid}")]
        [EnableCors("AllowMyOrigin")]
        public List<ApacRRMProjectDetails> GetProjectsList(string muid, string accountid, [FromHeader]string Authorization)
        {
            var result = new List<ApacRRMProjectDetails>();
            try
            {
                result = employee_BO.GetProjectsList(muid, accountid, Authorization);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetEmployeeTaggingDetailsList")]
        [EnableCors("AllowMyOrigin")]
        public List<EmployeeTaggingDetails> GetEmployeeTaggingDetailsList([FromHeader]string Authorization)
        {
            var result = new List<EmployeeTaggingDetails>();
            try
            {
                result = employee_BO.GetEmployeeTaggingDetailsList(Authorization);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpGet]
        [Route("api/GetProjectResourceDetailsList/{muId}/{accountId}/{projectcodes}")]
        [EnableCors("AllowMyOrigin")]
        public List<EmployeeDetailsPM> GetProjectResourceDetailsList(string muId, string accountId, string projectcodes, [FromHeader]string Authorization)
        {
            var result = new List<EmployeeDetailsPM>();
            try
            {
                result = employee_BO.GetProjectResourceDetailsList(muId, accountId, projectcodes, Authorization);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpPost]
        [Route("api/PostProjectResourceDetails")]
        [EnableCors("AllowMyOrigin")]
        public ActionResult PostResourceDetails([FromBody]List<EmployeeDetailsPM> employeeDetailsPM, [FromHeader]string Authorization)
        {
            var result = 0;
            try
            {
                for (var i = 0; i < employeeDetailsPM.Count; i++)
                {
                    var date = Convert.ToDateTime(employeeDetailsPM[i].newenddate.ToString().Substring(0, 10)).AddDays(1);
                    //var date = DateTime.ParseExact("Tue Jun 04 2019 00:00:00 GMT+0530 (India Standard Time)", "ddd MMM dd yyyy HH:mm:ss 'GMT'K '(India Standard Time)'", CultureInfo.InvariantCulture);                
                    string newDate = date.ToString("dd-MMM-yy", CultureInfo.InvariantCulture);
                    employeeDetailsPM[i].newenddate = newDate;
                    result = employee_BO.InsertUpdateResourceDetailsPM(employeeDetailsPM[i], Authorization);
                }
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return Ok(result);
        }

        [HttpGet]
        [Route("api/GetEmployeeDetailsRMG")]
        [EnableCors("AllowMyOrigin")]
        public List<EmployeeDetailsRMG> GetEmployeesListForRMG([FromHeader]string Authorization)
        {
            var result = new List<EmployeeDetailsRMG>();
            try
            {
                result = employee_BO.GetEmployeesListForRMG(Authorization);
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return result;
        }

        [HttpPut]
        [Route("api/PutProjectResourceDetails")]
        [EnableCors("AllowMyOrigin")]
        public ActionResult PutResourceDetails([FromBody]List<EmployeeDetailsRMG> employeeDetailsRMG, [FromHeader]string Authorization)
        {
            var result = 0;
            try
            {
                for (var i = 0; i < employeeDetailsRMG.Count; i++)
                {
                    result = employee_BO.UpdateResourceDetailsRMG(employeeDetailsRMG[i], Authorization);
                }
            }
            catch (Exception ex)
            {
                LogError.HandleError(ex, ex.StackTrace);
            }
            return Ok(result);
        }

    }
}