﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace Asset.ResourceReleaseManagement.APIServices
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseUrls(new string[] { "https://*:5000", "https://*:5001", "https://*:5002", "https://*:5003" })
                .UseStartup<Startup>();        
    }
}
