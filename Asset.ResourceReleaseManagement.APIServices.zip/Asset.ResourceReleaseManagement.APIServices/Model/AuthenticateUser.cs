﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class AuthenticateUser
    {
        public string userid { get; set; }
        public string  username { get; set; }
        public string password { get; set; }
        public string newPassword { get; set; }
        public string flag { get; set; }
    }
}
