﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class UserDetails
    {
        public string roleid { get; set; }
        public string role { get; set; }
        public string empid { get; set; }
        public string userid { get; set; }
        public string empname { get; set; }
    }
}
