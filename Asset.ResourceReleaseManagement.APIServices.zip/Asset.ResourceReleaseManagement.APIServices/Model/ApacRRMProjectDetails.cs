﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class ApacRRMProjectDetails
    {        
        public string pd_projectcode { get; set; }
        public string pd_projectname { get; set; }
        public int pd_muid { get; set; }
        public int Pd_accountid { get; set; }
        public string pd_status { get; set; }
    }
}
