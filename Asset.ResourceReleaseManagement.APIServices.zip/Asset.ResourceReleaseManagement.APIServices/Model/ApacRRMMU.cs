﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class ApacRRMMU
    {
        public int mu_id { get; set; }
        public string mu_name { get; set; }
        public string mu_status { get; set; }
        
    }
}
