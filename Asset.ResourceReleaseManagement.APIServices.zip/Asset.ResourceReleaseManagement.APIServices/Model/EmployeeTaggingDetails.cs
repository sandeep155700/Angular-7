﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class EmployeeTaggingDetails
    {
        public string employee { get; set; }
        public string empid { get; set; }
        public string empname { get; set; }
        public string grade { get; set; }
        public string serviceline { get; set; }
        public string skills { get; set; }
        public string status { get; set; }
        public string startdate { get; set; }
        public string enddate { get; set; }
        public string newenddate { get; set; }
        public string projectcode { get; set; }
        public string coment { get; set; }
        public string reasonforchange { get; set; }


    }
}
