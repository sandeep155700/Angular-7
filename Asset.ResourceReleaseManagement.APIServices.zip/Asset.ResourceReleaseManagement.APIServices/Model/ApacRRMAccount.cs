﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asset.ResourceReleaseManagement.APIServices.Model
{
    public class ApacRRMAccount
    {
        public int account_id { get; set; }
        public string account_name { get; set; }
        public string account_status { get; set; }
    }
}
