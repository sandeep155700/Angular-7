﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using Asset.ResourceReleaseManagement.APIServices.Oracle;
using Asset.ResourceReleaseManagement.APIServices.Model;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;

namespace Asset.ResourceReleaseManagement.APIServices.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        IConfiguration configuration;
        public EmployeeRepository(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        public List<AuthenticateUser> ChkFirstTimelogin(string userName)
        {
            var result = new List<AuthenticateUser>();
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string query = " Select APAC_RRM_USERS.RU_User_ID as userid,portal.APAC_PACE_TBL.userids as username,APAC_RRM_USERS.RU_PASSWORD as password,APAC_RRM_USERS.RU_FLAG as flag from portal.APAC_PACE_TBL " +
                               " Inner Join APAC_RRM_USERS ON portal.APAC_PACE_TBL.IDS = APAC_RRM_USERS.RU_EMPLOYEE_ID " +
                               " Where portal.APAC_PACE_TBL.userids = '" + userName + "' and ROWNUM = 1 and APAC_RRM_USERS.RU_STATUS='A'";
                OracleCommand cmdseq = new OracleCommand(query, conn);
                result = SqlMapper.Query<AuthenticateUser>(conn, query, commandType: CommandType.Text).ToList();
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public Boolean AuthenticateUser(string userName, string password)
        {
            bool result = false;
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string query = " Select portal.APAC_PACE_TBL.userids,APAC_RRM_USERS.RU_PASSWORD as password,APAC_RRM_USERS.RU_FLAG as flag from portal.APAC_PACE_TBL " +
                                " Inner Join APAC_RRM_USERS ON portal.APAC_PACE_TBL.IDS = APAC_RRM_USERS.RU_EMPLOYEE_ID " +
                                " Where portal.APAC_PACE_TBL.userids = '" + userName + "' and ROWNUM = 1 and APAC_RRM_USERS.RU_STATUS='A'";

                OracleCommand cmdseq = new OracleCommand(query, conn);
                OracleDataReader Rdr = cmdseq.ExecuteReader();
                string struserId = "";
                string strpassword = "";
                string strflag = "";

                if (Rdr.HasRows)
                {
                    while (Rdr.Read())
                    {
                        struserId = Convert.ToString(Rdr["userids"]);
                        strpassword = Convert.ToString(Rdr["password"]);
                        strflag = Convert.ToString(Rdr["flag"]);
                    }
                }

                Rdr.Close();
                conn.Close();

                if (password.Equals(DecryptString(strpassword)))
                {
                    result = true;
                }


            }
            catch
            {
                throw;
            }
            return result;
        }
        public int SetNewPassword(string userId, string userName, string password)
        {
            int result = 0;
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                using (var transaction = conn.BeginTransaction())
                {

                    string sql = "Update rrm_full.APAC_RRM_USERS SET APAC_RRM_USERS.RU_PASSWORD='" + EnryptString(password) + "',APAC_RRM_USERS.RU_FLAG=2 WHERE APAC_RRM_USERS.RU_User_ID='" + userId + "'";
                    OracleCommand cmd = new OracleCommand(sql, conn);
                    result = cmd.ExecuteNonQuery();
                    transaction.Commit();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public string GetUserRole(string userId)
        {
            string result = "";
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string query = " Select APAC_RRM_ROLEMASTER.ROLE from Apac_RRM_RoleMaster " +
                               " Inner Join APaC_RRM_Users on APAC_RRM_USERS.RU_ROLE_ID = APAC_RRM_ROLEMASTER.ROLE_ID " +
                               " Where APAC_RRM_USERS.RU_USER_ID = '" + userId + "' And APAC_RRM_USERS.RU_STATUS = 'A'";

                OracleCommand cmdseq = new OracleCommand(query, conn);
                //result = Convert.ToString(SqlMapper.Query(conn, query, commandType: CommandType.Text));
                OracleDataReader Rdr = cmdseq.ExecuteReader();
                if (Rdr.HasRows)
                {
                    while (Rdr.Read())
                    {
                        result = Convert.ToString(Rdr["ROLE"]);
                    }
                }
                Rdr.Close();
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public string GetLoggedInUserId(string userName)
        {
            string result = "";
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string query = " select RU.RU_USER_ID as userid " +
                                " from APAC_RRM_Rolemaster RM inner join APAC_RRM_USERS RU on RM.role_id = RU.RU_ROLE_ID " +
                                " Where RU.RU_Status='A' and RM.status='A' and RU.RU_Employee_Id IN( " +
                                " select ids from portal.APAC_PACE_TBL where userids= '" + userName + "' and ROWNUM = 1)";

                OracleCommand cmdseq = new OracleCommand(query, conn);
                //result = Convert.ToString(SqlMapper.Query(conn, query, commandType: CommandType.Text));
                OracleDataReader Rdr = cmdseq.ExecuteReader();
                if (Rdr.HasRows)
                {
                    while (Rdr.Read())
                    {

                        result = Convert.ToString(Rdr["userid"]);
                    }
                }
                Rdr.Close();
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<UserDetails> GetLoggedInUserDetails(string userName)
        {
            var result = new List<UserDetails>();
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string query = " with cte as( select RM.Role_id as roleid,RM.Role as role,RU.RU_Employee_Id as empid,RU.RU_USER_ID as userid " +
                                " from APAC_RRM_Rolemaster RM inner join APAC_RRM_USERS RU on RM.role_id = RU.RU_ROLE_ID " +
                                " Where RU.RU_Status='A' and RM.status='A' and RU.RU_Employee_Id IN( " +
                                " select ids from portal.APAC_PACE_TBL where userids= '" + userName + "' and ROWNUM = 1 and statuss='A'))" +
                                " select distinct cte.*,portal.APAC_PACE_TBL.Names as empname from cte left join portal.APAC_PACE_TBL on cte.Empid=portal.APAC_PACE_TBL.ids";
                OracleCommand cmdseq = new OracleCommand(query, conn);
                result = SqlMapper.Query<UserDetails>(conn, query, commandType: CommandType.Text).ToList();
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<ApacRRMMU> GetMUList(string userId)
        {
            var result = new List<ApacRRMMU>();
            try
            {
                string UserRole = GetUserRole(userId);
                var conn = this.GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string query = "";
                    if (UserRole.Equals("LEADERSHIP"))
                    {
                        query = " SELECT  MUNAME AS mu_name, MU_ID AS mu_id FROM rrm_full.apac_rrm_mu where status='A' and MU_ID IN( SELECT distinct pd_mu_id " +
                                " FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status='A' and pd_projectcode IN( SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink))";

                    }
                    else
                    {
                        query = "SELECT  MUNAME AS mu_name, MU_ID AS mu_id FROM rrm_full.apac_rrm_mu where status='A' and MU_ID IN( SELECT distinct pd_mu_id " +
                                    " FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status='A' and pd_projectcode IN( SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink " +
                                    " Where prl_userid = '" + userId + "')) ";
                    }
                    result = SqlMapper.Query<ApacRRMMU>(conn, query, commandType: CommandType.Text).ToList();

                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<ApacRRMAccount> GetAccountsList(string muid, string userId)
        {
            var result = new List<ApacRRMAccount>();
            try
            {
                string UserRole = GetUserRole(userId);
                var conn = this.GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string query = "";
                    if (UserRole.Equals("LEADERSHIP"))
                    {
                        query = " SELECT  ACCOUNTNAME AS account_name, ACCOUNT_ID AS account_id    FROM rrm_full.apac_rrm_account " +
                      " Where status='A' and ACCOUNT_ID IN( SELECT distinct pd_account_id FROM rrm_full.APAC_RRM_ProjectDetails " +
                      " Where pd_status='A' and pd_mu_id = '" + muid + "') order by account_id desc";
                    }
                    else
                    {
                        query = " SELECT  ACCOUNTNAME AS account_name, ACCOUNT_ID AS account_id    FROM rrm_full.apac_rrm_account " +
                       " Where status='A' and ACCOUNT_ID IN( SELECT distinct pd_account_id FROM rrm_full.APAC_RRM_ProjectDetails " +
                       " Where pd_status='A' and pd_mu_id = '" + muid + "' and pd_projectcode IN( SELECT  prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink " +
                       " Where prl_userid = '" + userId + "'))";
                    }
                    result = SqlMapper.Query<ApacRRMAccount>(conn, query, commandType: CommandType.Text).ToList();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<ApacRRMProjectDetails> GetProjectsList(string muid, string accountid, string userId)
        {
            var result = new List<ApacRRMProjectDetails>();
            try
            {
                string UserRole = GetUserRole(userId);
                var conn = GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string query = "";
                    if (UserRole.Equals("LEADERSHIP"))
                    {
                        query = " With cte as( SELECT  distinct pd_projectcode FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status='A' and pd_mu_id='" + muid + "' and " +
                              " pd_account_id='" + accountid + "' and pd_projectcode IN( SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink))" +
                              " Select distinct cte.*,(cte.pd_projectcode || ' - ' || portal.apac_r2d2_tagging.projectnames) as pd_projectname " +
                              " from cte left join portal.apac_r2d2_tagging on cte.pd_projectcode = portal.apac_r2d2_tagging.projectcodes ";
                    }
                    else
                    {
                        query = " With cte as( SELECT  distinct pd_projectcode FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status='A' and pd_mu_id='" + muid + "' and " +
                              " pd_account_id='" + accountid + "' and pd_projectcode IN( SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink where prl_userid = '" + userId + "'))" +
                              " Select distinct cte.*,(cte.pd_projectcode || ' - ' || portal.apac_r2d2_tagging.projectnames) as pd_projectname " +
                              " from cte left join portal.apac_r2d2_tagging on cte.pd_projectcode = portal.apac_r2d2_tagging.projectcodes ";
                    }
                    result = SqlMapper.Query<ApacRRMProjectDetails>(conn, query, commandType: CommandType.Text).ToList();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<EmployeeTaggingDetails> GetEmployeeTaggingDetailsList(string userId)
        {
            var result = new List<EmployeeTaggingDetails>();
            try
            {
                string UserRole = GetUserRole(userId);
                var conn = this.GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string query = "";
                    if (UserRole.Equals("LEADERSHIP"))
                    {
                        query = " WITH cte_employee_details AS(" +
                              " SELECT  ROW_NUMBER() OVER(PARTITION BY portal.apac_r2d2_tagging.EMPLOYEENOS ORDER BY portal.apac_r2d2_tagging.ENDDATES DESC) row_num," +
                              " (portal.APAC_PACE_TBL.IDS||' - '|| portal.APAC_PACE_TBL.NAMES) as employee," +
                              " portal.APAC_PACE_TBL.NAMES AS empname, portal.APAC_PACE_TBL.IDS AS empid, portal.APAC_PACE_TBL.Grades AS grade, portal.APAC_PACE_TBL.SUB_BUNAMES AS serviceline, portal.APAC_PACE_TBL.SERVICELINES AS skills, '' AS status," +
                              " STARTDATES AS startdate, ENDDATES AS enddate, (projectcodes|| ' - ' ||projectnames) as projectcode" +
                              " FROM portal.APAC_PACE_TBL, portal.apac_r2d2_tagging " +
                              " where portal.apac_r2d2_tagging.EMPLOYEENOS = portal.APAC_PACE_TBL.IDS " +
                              " and projectcodes IN(select pd_projectcode from rrm_full.APAC_RRM_PROJECTDETAILS where  pd_status='A' and PD_projectcode IN(" +
                              " SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink)) " +
                              " and to_date(portal.apac_r2d2_tagging.ENDDATES, 'MM-DD-YYYY') >= sysdate and portal.APAC_PACE_TBL.statuss='A' )" +
                              " SELECT cte_employee_details.*,to_char(rrm_full.APAC_RRM_RESOURCEDETAILS.newenddate,'MM/DD/YYYY') as newenddate, rrm_full.APAC_RRM_RESOURCEDETAILS.Status as status, " +
                              " rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Comment as coment ,rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Reasonforchange as reasonforchange FROM cte_employee_details " +
                              " LEFT JOIN rrm_full.APAC_RRM_RESOURCEDETAILS ON cte_employee_details.empid = rrm_full.APAC_RRM_RESOURCEDETAILS.EMPLOYEE_ID " +
                              " WHERE row_num = 1 and cte_employee_details.startdate is not null and cte_employee_details.enddate is not null " +
                              " order by to_date(cte_employee_details.enddate, 'MM-DD-YYYY') ASC";
                    }
                    else
                    {
                        query = " WITH cte_employee_details AS(" +
                               " SELECT  ROW_NUMBER() OVER(PARTITION BY portal.apac_r2d2_tagging.EMPLOYEENOS ORDER BY portal.apac_r2d2_tagging.ENDDATES DESC) row_num," +
                               " (portal.APAC_PACE_TBL.IDS||' - '|| portal.APAC_PACE_TBL.NAMES) as employee," +
                               " portal.APAC_PACE_TBL.NAMES AS empname, portal.APAC_PACE_TBL.IDS AS empid, portal.APAC_PACE_TBL.Grades AS grade, portal.APAC_PACE_TBL.SUB_BUNAMES AS serviceline, portal.APAC_PACE_TBL.SERVICELINES AS skills, '' AS status," +
                               " STARTDATES AS startdate, ENDDATES AS enddate, (projectcodes|| ' - ' ||projectnames) as projectcode" +
                               " FROM portal.APAC_PACE_TBL, portal.apac_r2d2_tagging " +
                               " where portal.apac_r2d2_tagging.EMPLOYEENOS = portal.APAC_PACE_TBL.IDS " +
                               " and projectcodes IN(select pd_projectcode from rrm_full.APAC_RRM_PROJECTDETAILS where  pd_status='A' and PD_projectcode IN(" +
                               " SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink where prl_userid = '" + userId + "')) " +
                               " and to_date(portal.apac_r2d2_tagging.ENDDATES, 'MM-DD-YYYY') >= sysdate and portal.APAC_PACE_TBL.statuss='A' )" +
                               " SELECT cte_employee_details.*,to_char(rrm_full.APAC_RRM_RESOURCEDETAILS.newenddate,'MM/DD/YYYY') as newenddate, rrm_full.APAC_RRM_RESOURCEDETAILS.Status as status, " +
                               " rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Comment as coment ,rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Reasonforchange as reasonforchange FROM cte_employee_details " +
                               " LEFT JOIN rrm_full.APAC_RRM_RESOURCEDETAILS ON cte_employee_details.empid = rrm_full.APAC_RRM_RESOURCEDETAILS.EMPLOYEE_ID " +
                               " WHERE row_num = 1 and cte_employee_details.startdate is not null and cte_employee_details.enddate is not null " +
                               " order by to_date(cte_employee_details.enddate, 'MM-DD-YYYY') ASC";
                    }
                    result = SqlMapper.Query<EmployeeTaggingDetails>(conn, query, commandType: CommandType.Text).ToList();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }

            return result;
        }
        public List<EmployeeDetailsPM> GetProjectResourceDetailsList(string muid, string accountid, string projectcodes, string userId)
        {
            var result = new List<EmployeeDetailsPM>();
            try
            {
                var conn = this.GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {

                    var query = " WITH cte_employee_details AS(" +
                                   " SELECT  ROW_NUMBER() OVER(PARTITION BY portal.apac_r2d2_tagging.EMPLOYEENOS ORDER BY portal.apac_r2d2_tagging.ENDDATES DESC) row_num," +
                                   " (portal.APAC_PACE_TBL.IDS||' - '|| portal.APAC_PACE_TBL.NAMES) as employee," +
                                   "  portal.APAC_PACE_TBL.NAMES AS empname, portal.APAC_PACE_TBL.IDS AS empid, portal.APAC_PACE_TBL.Grades AS grade, portal.APAC_PACE_TBL.SUB_BUNAMES AS serviceline, portal.APAC_PACE_TBL.SERVICELINES AS skills, '' AS status," +
                                   " STARTDATES AS startdate, ENDDATES AS enddate, (projectcodes|| ' - ' ||projectnames) as projectcode " +
                                   " FROM portal.APAC_PACE_TBL, portal.apac_r2d2_tagging " +
                                   " where portal.apac_r2d2_tagging.EMPLOYEENOS = portal.APAC_PACE_TBL.IDS ";

                    if ((!string.IsNullOrEmpty(muid)) && ((accountid.Equals("undefined")) || (accountid.Equals("59"))))
                    {
                        query += " and projectcodes IN(SELECT distinct pd_projectcode FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status= 'A' and pd_mu_id = '" + muid + "') ";
                    }
                    else if ((!string.IsNullOrEmpty(accountid)) && (projectcodes.Equals("undefined")) && (!accountid.Equals("59")))
                    {
                        query += " and projectcodes IN(SELECT distinct pd_projectcode FROM rrm_full.APAC_RRM_ProjectDetails where  pd_status= 'A' and pd_mu_id = '" + muid + "' " +
                                 " and pd_account_id='" + accountid + "') ";
                    }
                    else
                    {
                        query += " and projectcodes ='" + projectcodes + "' ";
                    }

                    query += " and to_date(portal.apac_r2d2_tagging.ENDDATES, 'MM-DD-YYYY') >= sysdate and portal.APAC_PACE_TBL.statuss='A' " +
                             " ) SELECT cte_employee_details.*,to_char(rrm_full.APAC_RRM_RESOURCEDETAILS.newenddate,'MM/DD/YYYY') as newenddate, rrm_full.APAC_RRM_RESOURCEDETAILS.Status as status, " +
                             " rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Comment as coment,rrm_full.APAC_RRM_RESOURCEDETAILS.RD_Reasonforchange as reasonforchange FROM cte_employee_details " +
                             " LEFT JOIN rrm_full.APAC_RRM_RESOURCEDETAILS ON cte_employee_details.empid = rrm_full.APAC_RRM_RESOURCEDETAILS.EMPLOYEE_ID " +
                             " WHERE row_num = 1" +
                             " and cte_employee_details.startdate is not null and cte_employee_details.enddate is not null " +
                             " order by to_date(cte_employee_details.enddate, 'MM-DD-YYYY') ASC";
                    result = SqlMapper.Query<EmployeeDetailsPM>(conn, query, commandType: CommandType.Text).ToList();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }

            return result;
        }
        public int InsertUpdateResourceDetailsPM(EmployeeDetailsPM employeeDetailsPM, string userId)
        {
            int result = 0;
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                string seq = ("Select Resource_id_seq.nextval from dual");
                OracleCommand cmdseq = new OracleCommand(seq, conn);
                var ResourceId = cmdseq.ExecuteScalar();

                using (var transaction = conn.BeginTransaction())
                {
                    string sql = "";
                    if (string.IsNullOrEmpty(employeeDetailsPM.status))
                    {
                        sql = "Insert Into rrm_full.APAC_RRM_ResourceDetails(Resource_id,ProjectCode,Employee_id,StartDate,EndDate," +
                           " NewEndDate,Status,CreatedBy,CreatedOn,RD_Comment,RD_Empname,RD_Grade,RD_Skills,RD_Serviceline,RD_Reasonforchange," +//)" +
                           " RD_Account)" +
                           " Values(" + ResourceId + ",'" + employeeDetailsPM.projectcode + "','" + employeeDetailsPM.empid + "'," +
                           " '" + Convert.ToDateTime(employeeDetailsPM.startdate).ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "'," +
                           "'" + Convert.ToDateTime(employeeDetailsPM.enddate).ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "'," +
                           "'" + employeeDetailsPM.newenddate + "',0,'" + userId + "'," +
                           "'" + DateTime.Now.ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "','" + employeeDetailsPM.coment + "'," +
                           "'" + employeeDetailsPM.empname + "','" + employeeDetailsPM.grade + "','" + employeeDetailsPM.skills + "'," +
                           "'" + employeeDetailsPM.serviceline + "','" + employeeDetailsPM.reasonforchange + "'," +//)";
                           " (Select (Account_ID|| ' - ' ||AccountName) as Accounts from rrm_full.APAC_RRM_ACCOUNT where ACCOUNT_ID = " +
                           " (Select PD_ACCOUNT_ID from rrm_full.APAC_RRM_PROJECTDETAILS where PD_ProjectCode = trim(REGEXP_SUBSTR('" + employeeDetailsPM.projectcode + "', '[^-]+', 1, 1)))))";

                    }
                    else
                    {
                        sql = "Update rrm_full.APAC_RRM_ResourceDetails SET NewEndDate='" + employeeDetailsPM.newenddate + "', Status=0,RD_Comment='" + employeeDetailsPM.coment + "'," +
                                 " ApprovedBy='" + userId + "', Approvedon='" + DateTime.Now.ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "', " +
                                 " RD_Reasonforchange='" + employeeDetailsPM.reasonforchange + "' Where Employee_id='" + employeeDetailsPM.empid + "'";
                    }
                    OracleCommand cmd = new OracleCommand(sql, conn);
                    result = cmd.ExecuteNonQuery();
                    transaction.Commit();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public List<EmployeeDetailsRMG> GetEmployeesListForRMG(string userId)
        {
            var result = new List<EmployeeDetailsRMG>();
            try
            {
                string UserRole = GetUserRole(userId);
                var conn = this.GetConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string query = "";
                    if (UserRole.Equals("LEADERSHIP"))
                    {
                        query = " with cte as (Select (EMPLOYEE_ID ||' - '||RD_EMPNAME) as employee,EMPLOYEE_ID as empid,RD_EMPNAME as empname,projectcode,RD_Grade as grade," +
                                " RD_ServiceLine as serviceline,RD_Skills as skills,to_char(startdate,'MM/DD/YYYY') as startdate," +
                                " to_char(enddate,'MM/DD/YYYY') as enddate,to_char(newenddate,'MM/DD/YYYY') as newenddate,status,RD_Comment as coment, " +
                                " RD_Reasonforchange as reasonforchange,CreatedBy, RD_ACCOUNT as accountname  from rrm_full.APAC_RRM_RESOURCEDETAILS " +
                                " where trim(REGEXP_SUBSTR(projectcode, '[^-]+', 1, 1)) IN(SELECT pd_projectcode from rrm_full.APAC_RRM_PROJECTDETAILS where  pd_status='A' and PD_projectcode IN ( " +
                                " SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink)))" +
                                " select distinct cte.*, (portal.APAC_PACE_TBL.IDS || ' - ' || portal.APAC_PACE_TBL.NAMES) as requestedby " +
                                " from cte left join portal.APAC_PACE_TBL on portal.APAC_PACE_TBL.IDS = cte.CreatedBy";
                    }
                    else
                    {
                        query = " with cte as (Select (EMPLOYEE_ID ||' - '||RD_EMPNAME) as employee,EMPLOYEE_ID as empid,RD_EMPNAME as empname,projectcode,RD_Grade as grade," +
                                 " RD_ServiceLine as serviceline,RD_Skills as skills,to_char(startdate,'MM/DD/YYYY') as startdate," +
                                 " to_char(enddate,'MM/DD/YYYY') as enddate,to_char(newenddate,'MM/DD/YYYY') as newenddate,status,RD_Comment as coment, " +
                                 " RD_Reasonforchange as reasonforchange,CreatedBy, RD_ACCOUNT as accountname  from rrm_full.APAC_RRM_RESOURCEDETAILS " +
                                 " where trim(REGEXP_SUBSTR(projectcode, '[^-]+', 1, 1)) IN(SELECT pd_projectcode from rrm_full.APAC_RRM_PROJECTDETAILS where  pd_status='A' and PD_projectcode IN ( " +
                                 " SELECT prl_pd_projectcode  FROM rrm_full.APAC_RRM_ProjectRoleLink where prl_userid = '" + userId + "')))" +
                                 " select distinct cte.*, (portal.APAC_PACE_TBL.IDS || ' - ' || portal.APAC_PACE_TBL.NAMES) as requestedby " +
                                 " from cte left join portal.APAC_PACE_TBL on portal.APAC_PACE_TBL.IDS = cte.CreatedBy";
                    }
                    result = SqlMapper.Query<EmployeeDetailsRMG>(conn, query, commandType: CommandType.Text).ToList();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }

            return result;
        }
        public int UpdateResourceDetailsRMG(EmployeeDetailsRMG employeeDetailsRMG, string userId)
        {
            int result = 0;
            try
            {
                OracleConnection conn = GetRRMDBConnection();
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                using (var transaction = conn.BeginTransaction())
                {
                    string sql = "";
                    if (employeeDetailsRMG.status.Equals("0") || employeeDetailsRMG.status.Equals("1") || employeeDetailsRMG.status.Equals("4"))
                    {
                        sql = "Update rrm_full.APAC_RRM_ResourceDetails SET Status='" + employeeDetailsRMG.status + "',RD_Comment='" + employeeDetailsRMG.coment + "'," +
                                " ApprovedBy='" + userId + "', Approvedon='" + DateTime.Now.ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "' " +
                                " Where Employee_id=" + employeeDetailsRMG.empid + "";
                    }
                    else if (employeeDetailsRMG.status.Equals("2") || employeeDetailsRMG.status.Equals("3"))
                    {
                        string seq = ("Select Resource_id_seq.nextval from dual");
                        OracleCommand cmdseq = new OracleCommand(seq, conn);
                        var ResourceId = cmdseq.ExecuteScalar();

                        string sqlInsert = "Insert Into rrm_full.APAC_RRM_RD_ARCHIVED(RDA_Resource_id,RDA_ProjectCode,RDA_Employee_id,RDA_StartDate,RDA_EndDate," +
                            " RDA_NewEndDate,RDA_Status,RDA_CreatedBy,RDA_CreatedOn,RDA_ApprovedBy,RDA_ApprovedOn,RDA_Comment,RD_Empname,RD_Grade,RD_Skills,RD_Serviceline,RD_Reasonforchange," +//)" +
                            " RD_Account)" +
                            " Values(" + ResourceId + ",'" + employeeDetailsRMG.projectcode + "','" + employeeDetailsRMG.empid + "'," +
                            " '" + Convert.ToDateTime(employeeDetailsRMG.startdate).ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "'," +
                            "'" + Convert.ToDateTime(employeeDetailsRMG.enddate).ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "'," +
                            "'" + Convert.ToDateTime(employeeDetailsRMG.newenddate).ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "',0,'" + userId + "'," +
                            "'" + DateTime.Now.ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "','" + userId + "'," +
                            "'" + DateTime.Now.ToString("dd-MMM-yy", CultureInfo.InvariantCulture) + "','" + employeeDetailsRMG.coment + "'," +
                            "'" + employeeDetailsRMG.empname + "','" + employeeDetailsRMG.grade + "','" + employeeDetailsRMG.skills + "'," +
                            "'" + employeeDetailsRMG.serviceline + "','" + employeeDetailsRMG.reasonforchange + "'," +//)";
                            " (Select (Account_ID|| ' - ' ||AccountName) as Accounts from rrm_full.APAC_RRM_ACCOUNT where ACCOUNT_ID = " +
                            " (Select PD_ACCOUNT_ID from rrm_full.APAC_RRM_PROJECTDETAILS where PD_ProjectCode = trim(REGEXP_SUBSTR('" + employeeDetailsRMG.projectcode + "', '[^-]+', 1, 1)))))";
                        OracleCommand cmdInsert = new OracleCommand(sqlInsert, conn);
                        result = cmdInsert.ExecuteNonQuery();

                        sql = "Delete from rrm_full.APAC_RRM_ResourceDetails Where Employee_id ='" + employeeDetailsRMG.empid + "'";
                    }
                    OracleCommand cmd = new OracleCommand(sql, conn);
                    result = cmd.ExecuteNonQuery();
                    transaction.Commit();
                }
                conn.Close();
            }
            catch
            {
                throw;
            }
            return result;
        }
        public string DecryptString(string encrString)
        {
            byte[] b;
            string decrypted;
            try
            {
                b = Convert.FromBase64String(encrString);
                decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
            }
            catch (FormatException fe)
            {
                decrypted = "";
            }
            return decrypted;
        }
        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
        public IDbConnection GetConnection()
        {
            var connectionString = configuration.GetSection("ConnectionStrings").GetSection("APACConnection").Value;
            var conn = new OracleConnection(connectionString);
            return conn;
        }
        public OracleConnection GetRRMDBConnection()
        {
            var connectionString = configuration.GetSection("ConnectionStrings").GetSection("RRMConnection").Value;
            var conn = new OracleConnection(connectionString);
            return conn;
        }

    }
}
