﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asset.ResourceReleaseManagement.APIServices.Model;

namespace Asset.ResourceReleaseManagement.APIServices.Repositories
{
    public interface IEmployeeRepository
    {
        List<AuthenticateUser> ChkFirstTimelogin(string userName);
        Boolean AuthenticateUser(string userName,string password);
        int SetNewPassword(string userId,string userName, string password);
        string GetUserRole(string userId);
        string GetLoggedInUserId(string userName);
        List<UserDetails> GetLoggedInUserDetails(string userName);
        List<ApacRRMMU> GetMUList(string userId);
        List<ApacRRMAccount> GetAccountsList(string muid, string userId);
        List<ApacRRMProjectDetails> GetProjectsList(string muid, string accountid, string userId);
        List<EmployeeTaggingDetails> GetEmployeeTaggingDetailsList(string userId);
        List<EmployeeDetailsPM> GetProjectResourceDetailsList(string muid, string account, string projectcodes, string userId);
        int InsertUpdateResourceDetailsPM(EmployeeDetailsPM employeeDetailsPM,string userId);
        List<EmployeeDetailsRMG> GetEmployeesListForRMG(string userId);
        int UpdateResourceDetailsRMG(EmployeeDetailsRMG employeeDetailsRMG,string userId);
    }
}
