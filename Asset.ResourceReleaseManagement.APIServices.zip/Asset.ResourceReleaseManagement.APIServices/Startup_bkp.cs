﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using Microsoft.AspNetCore.Http;

namespace Asset.ResourceReleaseManagement.APIServices
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.Run(async (Context) =>
            {
                // Basic ODP.NET Core application for ASP.NET Core
                // to connect, query, and return results to a web page

                //Create a connection to Oracle			
                //string conString = "User Id=rrm_full;Password=rrm_full;" +

                //How to connect to an Oracle DB without SQL*Net configuration file
                //  also known as tnsnames.ora.
                //"Data Source=10.246.65.42:1521/XE;";

                //How to connect to an Oracle DB with a DB alias.
                //Uncomment below and comment above.
                //"Data Source=RRM_Full;";

                string conString = "Data Source=10.246.65.42:1521/XE;User Id=rrm_full;Password=rrm_full;";

                using (OracleConnection con = new OracleConnection(conString))
                {
                    using (OracleCommand cmd = con.CreateCommand())
                    {
                        try
                        {
                            con.Open();
                            cmd.BindByName = true;

                            //Use the command to display employee names from 
                            // the EMPLOYEES table
                            //cmd.CommandText = "select NAMES from portal.apac_r2d2_tagging where EMPLOYEENOS = :id";
                            cmd.CommandText = "SELECT MUNAME from APAC_RRM_MU";
                            //cmd.CommandText = "INSERT INTO APAC_RRM_MU(MU_ID, MUNAME, STATUS)  VALUES(2, 'MU1', 0)";
                            //cmd.CommandText = "UPDATE APAC_RRM_MU SET MUNAME = 'MU2', STATUS='1' WHERE MU_ID = 2";



                            // Assign id to the department number 50 
                            //OracleParameter id = new OracleParameter("id", "167735");                 
                            //cmd.Parameters.Add(id);

                            //Execute the command and use DataReader to display the data
                            OracleDataReader reader = cmd.ExecuteReader();
                            //cmd.ExecuteNonQuery();

                            //string x;
                            //if (reader.HasRows) // file exists in DB
                            //{
                            //    reader.Read();
                            //    x = reader.GetString(0).ToString(); // return baseline filename (index 2)
                            //}
                            //else
                            //{
                            //    x = "New File";
                            //}

                            while (reader.Read())
                            {
                                //await Context.Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                                await Context.Response.WriteAsync("Employee First Name: " + reader.GetString(0).ToString() + "\n");
                            }

                            //reader.Dispose();
                        }
                        catch (Exception ex)
                        {
                            await Context.Response.WriteAsync(ex.Message);
                        }
                    }
                }

            });

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
