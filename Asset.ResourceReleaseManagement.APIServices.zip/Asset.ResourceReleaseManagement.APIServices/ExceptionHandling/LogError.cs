﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Text.RegularExpressions;

namespace Asset.ResourceReleaseManagement.APIServices.ExceptionHandling
{
    /// <summary>
    /// Summary description for LogError
    /// </summary>
    public static class LogError
    {
        public static object lockObject = new object();
        /// <summary>
        /// This method is used to write exception error logs
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="mFunction"></param>
        public static void HandleError(Exception ex, string mFunction)
        {
            lock (lockObject)
            {
                //Calling write log error function
                LogError.WriteLogError(mFunction, ex.Message);
            };
            //Displaying the current custom error message in to browser
            //  PopupMessage(ex.Message);
        }

        /// <summary>
        /// This method is used to write exception log error in to text files
        /// </summary>
        /// <param name="mFunction"></param>
        /// <param name="mError"></param>
        public static void WriteLogError(string mFunction, string mError)
        {
            StreamWriter fs;
            var exePath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            Regex appPathMatcher = new Regex(@"(?<!fil)[A-Za-z]:\\+[\S\s]*?(?=\\+bin)");
            var mErrorLogPath = Path.Combine(appPathMatcher.Match(exePath).Value, "ErrorLog\\");
            Directory.CreateDirectory(mErrorLogPath);
            if (!System.IO.File.Exists(@"" + mErrorLogPath + "ErrorLog_" + DateTime.Today.ToString("yyyyMMdd") + ".txt"))
            {
                fs = File.CreateText(@"" + mErrorLogPath + "ErrorLog_" + DateTime.Today.ToString("yyyyMMdd") + ".txt");
            }
            else
            {
                fs = File.AppendText(@"" + mErrorLogPath + "ErrorLog_" + DateTime.Today.ToString("yyyyMMdd") + ".txt");
            }

            fs.WriteLine(Convert.ToString(DateTime.Now) + " :" + mError + " :" + mFunction);
            fs.Close();
        }

        /// <summary>
        /// This method us used to displaying the current custom error message in to browser
        /// </summary>
        /// <param name="ex"></param>
        //private static void PopupMessage(string ex)
        //{
        //    var page = HttpContext.Current.CurrentHandler as Page;
        //    ScriptManager.RegisterStartupScript(page, page.GetType(), "alert", "alert('" + ex.Replace("'", "") + "');", true);
        //}
    }
}
