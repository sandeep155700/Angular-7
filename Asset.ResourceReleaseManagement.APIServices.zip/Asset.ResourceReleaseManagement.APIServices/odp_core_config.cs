﻿using System;
using Oracle.ManagedDataAccess.Client;

namespace Asset.ResourceReleaseManagement.APIServices
{
    class odp_core_config
    {
        static void Main(string[] args)
        {
            // This sample demonstrates how to use ODP.NET Core Configuration API

            // Add connect descriptors and net service names entries.
            //OracleConfiguration.OracleDataSources.Add("orclpdb", "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=<hostname or IP>)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=<service name>)(SERVER=dedicated)))");
            //OracleConfiguration.OracleDataSources.Add("orcl", "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=<hostname or IP>)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=<service name>)(SERVER=dedicated)))");
            OracleConfiguration.OracleDataSources.Add("XE", "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.246.65.42)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=RRM_Full)(SERVER=dedicated)))");

            // Set default statement cache size to be used by all connections.
            OracleConfiguration.StatementCacheSize = 25;

            // Disable self tuning by default.
            OracleConfiguration.SelfTuning = false;

            // Bind all parameters by name.
            OracleConfiguration.BindByName = true;

            // Set default timeout to 60 seconds.
            OracleConfiguration.CommandTimeout = 60;

            // Set default fetch size as 1 MB.
            OracleConfiguration.FetchSize = 1024 * 1024;

            // Set tracing options
            OracleConfiguration.TraceOption = 1;
            OracleConfiguration.TraceFileLocation = @"C:\traces";
            // Uncomment below to generate trace files
            //OracleConfiguration.TraceLevel = 7;

            // Set network properties
            OracleConfiguration.SendBufferSize = 8192;
            OracleConfiguration.ReceiveBufferSize = 8192;
            OracleConfiguration.DisableOOB = true;

            OracleConnection orclCon = null;

            try
            {
                // Open a connection
                orclCon = new OracleConnection("user id=rrm_full; password=rrm_full; data source=XE;");
                orclCon.Open();

                // Execute simple select statement that returns first 10 names from EMPLOYEES table
                OracleCommand orclCmd = orclCon.CreateCommand();
                orclCmd.CommandText = "SELECT MUNAME from APAC_RRM_MU";
                OracleDataReader rdr = orclCmd.ExecuteReader();

                while (rdr.Read())
                    Console.WriteLine("Employee Name: " + rdr.GetString(0).ToString());

                Console.ReadLine();

                rdr.Dispose();
                orclCmd.Dispose();
            }
            finally
            {
                // Close the connection
                if (null != orclCon)
                    orclCon.Close();
            }
        }
    }
}
