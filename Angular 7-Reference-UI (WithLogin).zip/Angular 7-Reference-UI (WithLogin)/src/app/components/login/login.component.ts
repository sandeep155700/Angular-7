import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { UserNameService } from '../../services/user-name.service';
import { RoleMasterService } from 'src/app/services/home.service';
import { Router } from '@angular/router';
import { DataSharingService } from '../../services/dataSharing.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  show: boolean;
  nameRequired: boolean;
  passwordRequired: boolean;
  newpasswordRequired: boolean;
  confirmNewPasswordRequired:boolean;

  public userdata: any;
  public roleData: any;
  constructor(public loginService: LoginService, public userNameService: UserNameService,
     private route: Router, public roleMstService: RoleMasterService, private dataSharingService: DataSharingService) { }

  ngOnInit() {
    this.userNameService.clearStorage();
  }

  onClickSubmit(data) {
    console.log(this.show);
    console.log(data.userName);
    if (!this.show) {

      if ((data.userName == "") || (data.userName == null)) {
        this.nameRequired = true;
      }
      else if (((data.password == "") || (data.password == null)) && !(this.show)) {
        this.passwordRequired = true;
        this.nameRequired = false;
      }
      else {
        this.passwordRequired = false;
        //this.newpasswordRequired = false;

        this.loginService.getFirstTimelogin(data.userName).subscribe((response) => {
          this.userdata = response;
          console.log(this.userdata);
          if (this.userdata.length == 0) {
            this.userNameService.setName('');
            this.userNameService.setUserId('');
            this.route.navigate(['/notAuth']);
          }
          else {
            if (this.userdata[0].flag == "1") {
              this.show = true;
              this.userNameService.setUserId(this.userdata[0].userid);
              this.userNameService.setUserName(this.userdata[0].username);
            }
            else {
              this.show = false;
              this.userNameService.setUserId(this.userdata[0].userid);
              this.userNameService.setUserName(this.userdata[0].username);
              this.loginService.getAuthenticateUser(data.userName, data.password).subscribe((response) => {
                this.userdata = response;
                if (this.userdata) {
                 // this.displayName();
                  this.dataSharingService.isUserLoggedIn.next(true);
                  this.route.navigate(['/home']);
                }
                else {
                  this.userNameService.setName('');
                  this.userNameService.setUserId('');
                  alert('Invalid Credentials!');
                }
                console.log(this.userdata);
              });
            }
          }
        })
      }
    }
    else {
      if ((data.userName == "") || (data.userName == null)) {
        this.nameRequired = true;
      }
      else if ((this.show && data.newPassword == "") || (this.show && data.newPassword == null)) {
        this.newpasswordRequired = true;
        this.nameRequired = false;
      }
      // else if ((this.show && data.confirmNewPassword == "") || (this.show && data.confirmNewPassword == null)) {
      //   this.confirmNewPasswordRequired = true;
      //   this.nameRequired = false;
      // }
      else if(data.newPassword!=data.confirmNewPassword)
      {
        this.confirmNewPasswordRequired = true;
        this.nameRequired = false;
        this.newpasswordRequired = false;
      }
      else {
        this.newpasswordRequired = false;
        this.confirmNewPasswordRequired=false;
        this.loginService.setNewPassword(data.userName, data.newPassword).subscribe((response) => {
          this.userdata = response;
          if (this.userdata == 1)
           //this.displayName();
            this.dataSharingService.isUserLoggedIn.next(true);
          this.route.navigate(['/home']);
        });
      }
    }
  }
  cancelClick() {
    this.show = false;
    this.nameRequired = false;
    this.passwordRequired = false;
    this.newpasswordRequired = false;
  }

  // displayName() {
  //   this.roleMstService.getLoggedinUserRole().subscribe((response) => {
  //     this.roleData = response;
  //     this.userNameService.setName('Welcome ' + this.roleData[0].empname);
  //   })

  // }
}
