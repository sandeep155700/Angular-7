import { Component, OnInit } from '@angular/core';
import {UserNameService} from '../../../services/user-name.service';
import { DataSharingService } from '../../../services/dataSharing.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isUserLoggedIn: boolean;
  userName;
  constructor(public userNameService: UserNameService,private dataSharingService: DataSharingService) {
    this.dataSharingService.isUserLoggedIn.subscribe( value => {
    this.isUserLoggedIn = value;
    this.userName = this.userNameService.getName();
  });
  }

  ngOnInit() {

  }

}
