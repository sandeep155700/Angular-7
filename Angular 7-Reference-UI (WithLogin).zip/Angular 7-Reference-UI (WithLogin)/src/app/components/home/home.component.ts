import { Component, OnInit } from '@angular/core';
import { RoleMasterService } from 'src/app/services/home.service';
import { ApacRRMRoleMaster } from 'src/app/models/ApacRRMRoleMaster';
import {UserNameService} from '../../services/user-name.service';
import { Router,  ActivatedRoute, RouterEvent, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { DataSharingService } from '../../services/dataSharing.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isPM: boolean = false;
  isRMG: boolean = false;
  public data: any;


  constructor(public roleMstService: RoleMasterService, public userNameService: UserNameService,
    private route: Router,private activatedRoute: ActivatedRoute, private dataSharingService: DataSharingService) { }

  ngOnInit() {
    // this.route.events.pipe(
    //   filter((event:RouterEvent)=>event instanceof NavigationEnd)
    // ).subscribe(()=>{
    //   this.getLoggedinUserRole();
    // });

    this.getLoggedinUserRole();

  }
  getLoggedinUserRole() {
    this.roleMstService.getLoggedinUserRole().subscribe((response) => {
      this.data = response;
      if(this.data.length==0)
      {
        this.userNameService.setName('');
       // this.route.navigate(['/notAuth']);
       this.route.navigate(['']);
      }
      else
      {
        this.userNameService.setName('Welcome '+this.data[0].empname);
        this.dataSharingService.isUserLoggedIn.next(true);
      }

      this.data.forEach(element => {
      console.log(element["role"]);
      if(element["role"]=="PM" || element["role"]=="PMO")
      {
        this.isPM = true;

      }
      else if(element["role"]=="RMG")
      {
        this.isRMG = true;
      }
      else if(element["role"]=="LEADERSHIP")
      {
        this.isPM = true;
        this.isRMG = true;
      }
      else{
        //let returnUrl = this.activatedRoute.snapshot.queryParamMap.get('returnUrl');
         // this.route.navigate([returnUrl || 'home/notAuth']);// child url
       // this.route.navigate(['/notAuth']);
        this.route.navigate(['']);
      }
      });
    });
  }
}
