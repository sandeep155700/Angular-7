import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {EmployeeTaggingData} from 'src/app/models/EmployeeTaggingData';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { UserNameService } from '../services/user-name.service';


@Injectable({
  providedIn: 'root'
})
export class pendingEmployeeService {
    private BaseUrl=environment.apiUrl;

    constructor(private http: HttpClient,public userNameService: UserNameService) {}

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization':this.userNameService.getUserId()
      })
      };
      getLoggedinUserRole(){
        return this.http.get(this.BaseUrl+'GetLoggedinUserRole/'+this.userNameService.getUserName());
        }
      getEMployeeForRMG():Observable<EmployeeTaggingData[]>{
        return this.http.get<EmployeeTaggingData[]>(this.BaseUrl+'GetEmployeeDetailsRMG',this.httpOptions);
        }

        updateProjectResourceDetails(projectResourceDetails){
          return this.http.put(this.BaseUrl+ 'PutProjectResourceDetails', projectResourceDetails,this.httpOptions)
        }


    }
