import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
providedIn: 'root'
})
export class UserNameService {

constructor( http: HttpClient) { }

setName(name: string){
localStorage.removeItem('name');
//localStorage.clear();
localStorage.setItem('name', name );
}

getName(){
return localStorage.getItem('name');
}

setUserId(userid:string){
  localStorage.removeItem('userid');
  //localStorage.clear();
  localStorage.setItem('userid', userid );
}

getUserId(){
  return localStorage.getItem('userid');
  }

  setUserName(username:string){
    localStorage.removeItem('username');
    //localStorage.clear();
    localStorage.setItem('username', username );
  }

  getUserName(){
    return localStorage.getItem('username');
    }

    clearStorage()
    {
      localStorage.clear();
    }
}


