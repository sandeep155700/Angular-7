import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CdkTableModule} from '@angular/cdk/table';
import {NgModule} from '@angular/core';
import {ReactiveFormsModule} from '@angular/forms';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {DatePipe} from '@angular/common';
// import 'rxjs/add/observable/of';
import { SatPopoverModule } from '@ncstate/sat-popover';
import { AppRoutingModule } from './app-routing.module';
import {TooltipModule} from '../../node_modules/ngx-tooltip';

// import { JwModal } from '../../node_modules/jw-react-modal/lib/JwModal';
// Angular Materials Modules lists included here
import {
  MatTabsModule,
  MatTableModule,
  MatSortModule,
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatRippleModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatIconModule,
  MatToolbarModule,
  MatPaginatorModule,
  MatDividerModule,
  MatCardModule,
  MatChipsModule,
  MatSnackBarModule,
  MatDialogModule,
  MatSelectModule,
  MatTreeModule,
} from '@angular/material';

// Component lists
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/home/header/header.component';
import { FooterComponent } from './components/home/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { CurrentEmployeeComponent } from './components/employee/current-employee/current-employee.component';
import { PendingEmployeeComponent } from './components/employee/pending-employee/pending-employee.component';
import { AdminViewComponent } from './components/employee/admin-view/admin-view.component';
// import { ModalComponent } from './_components';
import { AddemployeeComponent } from './dialogs/addemployee/addemployee.component';
import { AdduserroleComponent } from './dialogs/adduserrole/adduserrole.component';
import { AddcommentComponent } from './dialogs/addcomment/addcomment.component';
import { DataService } from './services/data.service';
import { NotAuthorizedComponent } from './components/not-authorized/not-authorized.component';
import { LoginComponent } from './components/login/login.component';
import { DataSharingService } from './services/dataSharing.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    CurrentEmployeeComponent,
    PendingEmployeeComponent,
    AdminViewComponent,
    AddemployeeComponent,
    AdduserroleComponent,
    AddcommentComponent,
    NotAuthorizedComponent,
    LoginComponent,
  ],
  imports: [
    MatTabsModule,
    MatTableModule,
    MatSortModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatIconModule,
    MatToolbarModule,
    MatSelectModule,
    MatDividerModule,
    MatCardModule,
    MatChipsModule,
    MatTreeModule,
    MatSnackBarModule,
    MatDialogModule,
    HttpClientModule,
    CdkTableModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    SatPopoverModule,
    TooltipModule
  ],
  providers: [HttpClientModule, DataService, DatePipe,DataSharingService],
  bootstrap: [AppComponent],
  entryComponents: [AddemployeeComponent, AdduserroleComponent, AddcommentComponent]
})
export class AppModule {  }
