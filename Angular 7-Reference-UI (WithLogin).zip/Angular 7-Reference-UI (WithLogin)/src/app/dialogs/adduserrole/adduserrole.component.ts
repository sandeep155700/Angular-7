import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-adduserrole',
  templateUrl: './adduserrole.component.html',
  styleUrls: ['./adduserrole.component.css']
})
export class AdduserroleComponent implements OnInit {

  form: FormGroup;
  description: string;
  options: EmployeeDetails[];

  constructor(
      private fb: FormBuilder,
      private dialogRef: MatDialogRef<AdduserroleComponent>,
      @Inject(MAT_DIALOG_DATA) data
      ) {
      this.options = data;
  }

  ngOnInit() {
  }

  save() {
    this.dialogRef.close(this.form.value);
  }

  close() {
      this.dialogRef.close();
  }

}
export interface EmployeeDetails {
  position: number;
  name: string;
  empid: number;
  role: string;
  actions: string;
}

