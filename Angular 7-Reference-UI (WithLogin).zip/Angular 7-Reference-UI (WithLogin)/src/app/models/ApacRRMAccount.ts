export class ApacRRMAccount {
    accountid: number;
    accountname: string;
    status: string;
}
