export class ApacRRMAuthEmpRoleLink {
    authid: number;
    roleid: number;
    employeeid: string;
    muid: number;
    accountid: number;
    status: string;
}
