// import { Component, OnInit } from '@angular/core';
import * as tslib_1 from "tslib";
// @Component({
//   selector: 'app-admin-view',
//   templateUrl: './admin-view.component.html',
//   styleUrls: ['./admin-view.component.css']
// })
// export class AdminViewComponent implements OnInit {
//   constructor() { }
//   ngOnInit() {
//   }
// }
import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
/**
 * @title Table with pagination and sorting for displaying existing employees data
 */
var AdminViewComponent = /** @class */ (function () {
    function AdminViewComponent() {
        this.displayedColumns = ['position', 'name', 'empid', 'role', 'updateaction', 'deleteaction'];
        this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    }
    AdminViewComponent.prototype.ngOnInit = function () {
        this.dataSource.paginator = this.paginator;
    };
    AdminViewComponent.prototype.ngAfterViewInit = function () {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    };
    tslib_1.__decorate([
        ViewChild(MatPaginator),
        tslib_1.__metadata("design:type", MatPaginator)
    ], AdminViewComponent.prototype, "paginator", void 0);
    tslib_1.__decorate([
        ViewChild(MatSort),
        tslib_1.__metadata("design:type", MatSort)
    ], AdminViewComponent.prototype, "sort", void 0);
    AdminViewComponent = tslib_1.__decorate([
        Component({
            selector: 'app-admin-view',
            styleUrls: ['./admin-view.component.css'],
            templateUrl: './admin-view.component.html',
        })
    ], AdminViewComponent);
    return AdminViewComponent;
}());
export { AdminViewComponent };
// Dummy Data in JSON Format
var ELEMENT_DATA = [
    { position: 1, name: 'Yogesh', empid: 10079, role: 'LEAD', updateaction: '', deleteaction: '' },
    { position: 2, name: 'Harish', empid: 40026, role: 'PMO', updateaction: '', deleteaction: '' },
    { position: 3, name: 'Majanu', empid: 6941, role: 'RMG', updateaction: '', deleteaction: '' },
    { position: 4, name: 'Ruzuta', empid: 90122, role: 'PM', updateaction: '', deleteaction: '' },
    { position: 5, name: 'Suresh', empid: 10811, role: 'ADMIN', updateaction: '', deleteaction: '' }
];
// // Dummy Data in JSON Format
// const ELEMENT_DATA: EmployeeDetails[] = [
//   {position: 1, name: 'Yogesh', empid: 10079, role: 'H', editaction: '',deleteaction: ''},
//   {position: 2, name: 'Harish', empid: 40026, role: 'He', editaction: '',deleteaction: ''},
//   {position: 3, name: 'Majanu', empid: 6941, role: 'Li', editaction: '',deleteaction: ''},
//   {position: 4, name: 'Ruzuta', empid: 90122, role: 'Be', editaction: '',deleteaction: ''},
//   {position: 5, name: 'Suresh', empid: 10811, role: 'B', editaction: '',deleteaction: ''},
//   {position: 6, name: 'Sandeep', empid: 120107, role: 'C', editaction: '',deleteaction: ''},
//   {position: 7, name: 'Srihari', empid: 140067, role: 'N', editaction: '',deleteaction: ''},
//   {position: 8, name: 'Sudarshan', empid: 159994, role: 'O', editaction: '',deleteaction: ''},
//   {position: 9, name: 'Ajit', empid: 189984, role: 'F', editaction: '',deleteaction: ''},
//   {position: 10, name: 'Ritesh', empid: 201797, role: 'Ne', editaction: '',deleteaction: ''},
//   {position: 11, name: 'Gaurav', empid: 229897, role: 'Na', editaction: '',deleteaction: ''},
//   {position: 12, name: 'Vinod', empid: 24305, role: 'Mg', editaction: '',deleteaction: ''},
//   {position: 13, name: 'Vikash', empid: 269815, role: 'Al', editaction: '',deleteaction: ''},
//   {position: 14, name: 'Pankaj', empid: 280855, role: 'Si', editaction: '',deleteaction: ''},
//   {position: 15, name: 'Tarun', empid: 309738, role: 'P', editaction: '',deleteaction: ''},
//   {position: 16, name: 'Shilpa', empid: 32065, role: 'S', editaction: '',deleteaction: ''},
//   {position: 17, name: 'Naveen', empid: 35453, role: 'Cl', editaction: '',deleteaction: ''},
//   {position: 18, name: 'Pradeep', empid: 39948, role: 'Ar', editaction: '',deleteaction: ''},
//   {position: 19, name: 'Kavya', empid: 390983, role: 'K', editaction: '',deleteaction: ''},
//   {position: 20, name: 'Lal Sahab', empid: 40078, role: 'Ca', editaction: '',deleteaction: ''},
// ];
//# sourceMappingURL=admin-view.component.js.map