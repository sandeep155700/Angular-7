import * as tslib_1 from "tslib";
import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
/**
 * @title Table with pagination and sorting for displaying existing employees data
 */
var CurrentEmployeeComponent = /** @class */ (function () {
    function CurrentEmployeeComponent() {
        this.displayedColumns = ['position', 'name', 'empid', 'grade', 'si', 'skills', 'startdate', 'enddate', 'newenddate'];
        this.dataSource = new MatTableDataSource(ELEMENT_DATA);
        this.munames = [
            { value: '0', viewValue: 'Select-0' },
        ];
        this.accounts = [
            { value: '0', viewValue: 'Role-1' },
            { value: '1', viewValue: 'Role-2' },
            { value: '2', viewValue: 'Role-3' }
        ];
        this.projects = [
            { value: '0', viewValue: 'Project-1' },
            { value: '1', viewValue: 'Project-2' },
            { value: '2', viewValue: 'Project-3' },
            { value: '3', viewValue: 'Project-4' },
            { value: '4', viewValue: 'Project-5' },
            { value: '5', viewValue: 'Project-6' },
            { value: '6', viewValue: 'Project-7' },
            { value: '7', viewValue: 'Project-8' },
            { value: '8', viewValue: 'Project-9' },
            { value: '9', viewValue: 'Project-10' }
        ];
    }
    CurrentEmployeeComponent.prototype.ngOnInit = function () {
        this.dataSource.paginator = this.paginator;
    };
    CurrentEmployeeComponent.prototype.ngAfterViewInit = function () {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    };
    tslib_1.__decorate([
        ViewChild(MatPaginator),
        tslib_1.__metadata("design:type", MatPaginator)
    ], CurrentEmployeeComponent.prototype, "paginator", void 0);
    tslib_1.__decorate([
        ViewChild(MatSort),
        tslib_1.__metadata("design:type", MatSort)
    ], CurrentEmployeeComponent.prototype, "sort", void 0);
    CurrentEmployeeComponent = tslib_1.__decorate([
        Component({
            selector: 'app-current-employee',
            styleUrls: ['./current-employee.component.css'],
            templateUrl: './current-employee.component.html',
        })
    ], CurrentEmployeeComponent);
    return CurrentEmployeeComponent;
}());
export { CurrentEmployeeComponent };
// Dummy Data in JSON Format
var ELEMENT_DATA = [
    { position: 1, name: 'Yogesh', empid: 10079, grade: 'H', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 2, name: 'Harish', empid: 40026, grade: 'He', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 3, name: 'Majanu', empid: 6941, grade: 'Li', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 4, name: 'Ruzuta', empid: 90122, grade: 'Be', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 5, name: 'Suresh', empid: 10811, grade: 'B', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 6, name: 'Sandeep', empid: 120107, grade: 'C', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 7, name: 'Srihari', empid: 140067, grade: 'N', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 8, name: 'Sudarshan', empid: 159994, grade: 'O', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 9, name: 'Ajit', empid: 189984, grade: 'F', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 10, name: 'Ritesh', empid: 201797, grade: 'Ne', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 11, name: 'Gaurav', empid: 229897, grade: 'Na', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 12, name: 'Vinod', empid: 24305, grade: 'Mg', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 13, name: 'Vikash', empid: 269815, grade: 'Al', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 14, name: 'Pankaj', empid: 280855, grade: 'Si', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 15, name: 'Tarun', empid: 309738, grade: 'P', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 16, name: 'Shilpa', empid: 32065, grade: 'S', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 17, name: 'Naveen', empid: 35453, grade: 'Cl', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 18, name: 'Pradeep', empid: 39948, grade: 'Ar', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 19, name: 'Kavya', empid: 390983, grade: 'K', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
    { position: 20, name: 'Lal Sahab', empid: 40078, grade: 'Ca', si: '', startdate: '', enddate: '', skills: '', newenddate: '' },
];
//# sourceMappingURL=current-employee.component.js.map