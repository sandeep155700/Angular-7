import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogConfig} from '@angular/material';
import { AdduserroleComponent } from 'src/app/dialogs/adduserrole/adduserrole.component';
import { DataService } from 'src/app/services/data.service';
import { Employee } from 'src/app/models/Employee';

/**
 * @title Table with pagination and sorting for displaying existing employees data
 */
@Component({
  selector: 'app-admin-view',
  styleUrls: ['./admin-view.component.css'],
  templateUrl: './admin-view.component.html',
})

export class AdminViewComponent implements OnInit {

  constructor(public dialog: MatDialog, private employeeService:DataService
    ) { }
  displayedColumns: string[] = ['position', 'name', 'empid', 'role', 'actions'];
// Dummy Data in JSON Format
ELEMENT_DATA: EmployeeDetails[] = [
  {position: 1, name: 'Yogesh', empid: 10079, role: 'LEADERSHIP', actions: ''},
  {position: 2, name: 'Harish', empid: 40026, role: 'PMO', actions: ''},
  {position: 3, name: 'Majanu', empid: 6941, role: 'RMG', actions: ''},
  {position: 4, name: 'Ruzuta', empid: 90122, role: 'PM', actions: ''},
  {position: 5, name: 'Suresh', empid: 10811, role: 'ADMIN', actions: ''}
];
 // dataSource = new MatTableDataSource<EmployeeDetails>(this.ELEMENT_DATA);
  options: EmployeeDetails[] = this.ELEMENT_DATA;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
   // this.dataSource.paginator = this.paginator;
   // this.reloadData();
    
  }
 
// tslint:disable-next-line: use-life-cycle-interface
 // ngAfterViewInit() {
   // this.dataSource.paginator = this.paginator;
    //this.dataSource.sort = this.sort;
 // }
  openDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = this.ELEMENT_DATA;
    const dialogRef = this.dialog.open(AdduserroleComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
        data => console.log('Dialog output:', data)
    );

    dialogConfig.position = {
      top: '0',
      left: '1'
    };
  }

}

export interface EmployeeDetails {
  position: number;
  name: string;
  empid: number;
  role: string;
  actions: string;
}




