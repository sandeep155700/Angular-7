import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatPaginator, MatSort, MatSortable, MatTableDataSource, MatDialog, MatDialogConfig } from '@angular/material';
// import { ModalService } from 'src/app/_services';
import { AddemployeeComponent } from 'src/app/dialogs/addemployee/addemployee.component';
import { DataService } from 'src/app/services/data.service';
import { currentEmployeeService } from 'src/app/services/current-employee.service';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';
import { EmployeeTaggingData } from 'src/app/models/EmployeeTaggingData';
import { CurrentEmployee } from 'src/app/models/current-employee.model';
import { DatePipe } from '@angular/common';



/**
 * @title Table with pagination and sorting for displaying existing employees data
 */
@Component({
  selector: 'app-current-employee',
  styleUrls: ['./current-employee.component.css'],
  templateUrl: './current-employee.component.html',
})
export class CurrentEmployeeComponent implements OnInit {
  messages: any;
  currentEmployees: EmployeeTaggingData[];
  muId: string;
  projectId:string;
  accountId:string;

  selected: EmployeeTaggingData[] = [];
  reasonsforChange = [
    { value: '0', display: 'Early Release - Scope Reduction' },
    { value: '1', display: 'Early Release - Skills Issue' },
    { value: '2', display: 'Early Release - Discipline Issue' },
    { value: '3', display: 'Early Release - Project Closure' },
    { value: '4', display: 'Early Release - Resignation' },
    { value: '5', display: 'Extension - Role Extended' },
    { value: '6', display: 'Extension - New Opportunity' }

  ];

  @Input() MU;
  @Input() Accounts;
  @Input() Projects;
  fourWeeks;
  twoWeeks;
  chkObjValues: boolean;
  duplicateEndDate: string;
  chkelement: boolean;
  public roleData: any;
  isLeadership: boolean;
  count: number;
  twoWeeksFromToday: Date;
  fourweekcount: number;
  fourWeeksFromToday: Date;

  private readonly newProperty = this;

  constructor(public dialog: MatDialog, public dataService: DataService,
    public currentEmpService: currentEmployeeService, public datepipe: DatePipe
  ) { }

  dataSource: MatTableDataSource<EmployeeTaggingData>;
  displayedColumns: string[] = ['ROW_NUM', 'EMPLOYEE', 'PROJECT', 'GRADE', 'SERVICELINE', 'SKILLS', 'STARTDATE', 'ENDDATE', 'NEWENDDATE', 'REASONFORCHANGE', 'COMMENT', 'STATUS'];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  currentDate = new Date();
  lessThanTwoWeeks = new Date(this.currentDate.getTime() + (14 * 24 * 60 * 60 * 1000));
  lessThanFourWeeks = new Date(this.currentDate.getTime() + (28 * 24 * 60 * 60 * 1000));

  currentEmpForm = new FormGroup({
    MU: new FormControl(''),
    Account: new FormControl(''),
    Project: new FormControl('')
  })

  ngOnInit() {
    console.log(this.lessThanFourWeeks, this.lessThanTwoWeeks);
    this.reloadData();
    this.chkObjValues = true;
    this.getLoggedinUserRole();
    this.getMU();
    let element = new Date('12-30-2019');
    this.fourWeeks = this.datepipe.transform(this.lessThanFourWeeks, 'MM/dd/yyyy');
    this.twoWeeks = this.datepipe.transform(this.lessThanTwoWeeks, 'MM/dd/yyyy');
    if ((this.lessThanFourWeeks > element)
      && (element > this.lessThanTwoWeeks)) {
      console.log('true');
    }

    // let currentDate = new Date();
    // let lessThanTwoWeeks = new Date(this.currentDate.getTime() + (14 * 24 * 60 * 60 * 1000));
    // let lessThanFourWeeks = new Date(this.currentDate.getTime() + (200 * 24 * 60 * 60 * 1000));
    //console.log(lessThanTwoWeeks);
    //console.log(lessThanFourWeeks)

    // this.dataSource.sort = this.sort;
    //this.dataSource.paginator = this.paginator;
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getMU() {
    this.currentEmpService.MU().subscribe((response) => {
      this.MU = response;
      if (this.MU.length == 1) {
        this.currentEmpForm.patchValue({
          MU: this.MU[0].mu_id
        });
        this.muId = this.MU[0].mu_id;
        this.currentEmpService.accounts(this.MU[0].mu_id).subscribe((response) => {
          this.Accounts = response;

          if (this.Accounts.length == 1) {
            this.currentEmpForm.patchValue({
              Account: this.Accounts[0].account_id
            });
            this.accountId=this.Accounts[0].account_id;
            this.currentEmpService.projects(this.muId, this.Accounts[0].account_id).subscribe((response) => {
              this.Projects = response;
            })
          }
        })
      }
    })
  }

  getAccounts(muId) {
    this.muId = muId.value;
    this.accountId=undefined;
    console.log(muId.value);
    this.currentEmpService.accounts(muId.value).subscribe((response) => {
      this.Accounts = response;

      if (this.Accounts.length == 1) {
        this.currentEmpForm.patchValue({
          Account: this.Accounts[0].account_id
        });
        this.currentEmpService.projects(this.muId, this.Accounts[0].account_id).subscribe((response) => {
          this.Projects = response;
        })
      }

    });
  }


  getProjects(accountId) {
    console.log(accountId)
    this.accountId=accountId.value;
    this.projectId=undefined;
    this.currentEmpService.projects(this.muId, accountId.value).subscribe((response) => {
      this.Projects = response;
    })
  }


  addNewDate(event, element) {
    element.newenddate = event.value;
    this.duplicateEndDate = element.empid;
    this.chkelement = true;
    if ((element.reasonforchange == null) || (element.status == "0" && element.reasonforChange != "0")) {
      element.reasonforchange = "0";
    }
    console.log(element);
    console.log(this.datepipe.transform(element.newenddate, 'MM/dd/yyyy'));
    console.log(this.twoWeeks);
    this.chkObjValues = true;
    if (this.datepipe.transform(element.newenddate, 'MM/dd/yyyy') < this.twoWeeks) {
      alert('New End date cannot be with in 2 weeks for EmployeeId: ' + element.empid);
    }
  }

  reasonforChange(element, event) {
    console.log(element.reasonforchange);
    this.chkObjValues = true;
    if (element.reasonforchange == "0") {
      element.reasonforchange = event.value;
      if (this.selected.length == 0) {
        this.selected.push(element);
      }
      else {
        this.selected.forEach(loopelement => {
          if (loopelement["empid"] == element.empid) {
            this.chkelement = false;
          }
        });
        if (this.chkelement) {
          this.selected.push(element);
        }
      }
      console.log(this.selected);
    }
    else {

      element.reasonforchange = event.value;
      //console.log(element.reasonforChange);
    }

  }

  onChange(event, element) {
    element.coment = event;
    console.log(element, event);
  }

  addResourceDetails() {
    console.log(this.selected);

    if(this.selected.length==0)
    {
      alert('Please Select Atleast One Employee!');
    }
    else{
    this.selected.forEach(element => {
      if (this.datepipe.transform(element["newenddate"], 'MM/dd/yyyy') > this.twoWeeks) {
        if (element["reasonforchange"] == null || element["reasonforchange"] == 0) {
          alert('Reason for Change cannot be null!');
          this.chkObjValues = false;
        }
      } else {
        this.chkObjValues = false;
        alert('New End date cannot be with in 2 weeks for EmployeeId: ' + element["empid"]);
      }

    });
    console.log(this.chkObjValues);
    if (this.chkObjValues) {
      console.log(this.selected);
      this.currentEmpService.insertProjectResourceDetails(this.selected).subscribe((response: CurrentEmployee[]) => {
        console.log(response);
        this.currentEmployees = response;
        this.dataSource = new MatTableDataSource(this.currentEmployees);
        this.duplicateEndDate = '';
        if (this.projectId == null) {
          this.reloadData();
        }
        else {
          this.getCurrentEmpsRelatedToProject();
        }
        this.selected = [];
      });
    }
  }
  }

  getProjectId(projectId) {
    this.projectId = projectId.value;
  }
  getCurrentEmpsRelatedToProject() {

    // let target = projectId.source.selected._element.nativeElement;
    // let selectedData = {
    //   value: projectId.value,
    //   text: target.innerText.trim()
    // };
    console.log(this.muId,this.Accounts,this.projectId);
    this.currentEmpService.getCurrentEmpsRelatedToProject( this.muId,this.accountId,this.projectId).subscribe((response: CurrentEmployee[]) => {

      console.log(response);
      this.currentEmployees = response;
      this.dataSource = new MatTableDataSource(this.currentEmployees);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;

      //For Rolloff 2 and 4 weeks
      this.count = 0;
      this.fourweekcount = 0;
      this.currentEmployees.forEach(element => {

        this.twoWeeksFromToday = this.addDays(new Date(), 14);
        this.fourWeeksFromToday = this.addDays(new Date(), 28);
        let chkEndDate = new Date(element['enddate']);

        if (this.twoWeeksFromToday > chkEndDate) {
          this.count = this.count + 1;
        }

        if ((this.fourWeeksFromToday > chkEndDate)&&(chkEndDate>this.twoWeeksFromToday)) {
          this.fourweekcount = this.fourweekcount + 1;
        }
      });
    });
  }
  addDays(theDate, days) {
    return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
  }
  reloadData() {
    this.currentEmpService.currentEmployees().subscribe((response: EmployeeTaggingData[]) => {
      console.log(response);
      this.currentEmployees = response;
      this.dataSource = new MatTableDataSource(this.currentEmployees);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;

      //For Rolloff 2 and 4 weeks
      this.count = 0;
      this.fourweekcount = 0;
      this.currentEmployees.forEach(element => {

        this.twoWeeksFromToday = this.addDays(new Date(), 14);
        this.fourWeeksFromToday = this.addDays(new Date(), 28);
        let chkEndDate = new Date(element['enddate']);

        if (this.twoWeeksFromToday > chkEndDate) {
          this.count = this.count + 1;
        }

        if ((this.fourWeeksFromToday > chkEndDate)&&(chkEndDate>this.twoWeeksFromToday)) {
          this.fourweekcount = this.fourweekcount + 1;
        }
      });

    });
  }

  getLoggedinUserRole() {
    this.currentEmpService.getLoggedinUserRole().subscribe((response) => {
      this.roleData = response;
      if (this.roleData.length > 0) {
        if (this.roleData[0].role == "LEADERSHIP")
          this.isLeadership = true;
        console.log(this.isLeadership);
      }
    });
  }

  openDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = {
      id: 1,
      title: 'Test'
    };
    const dialogRef = this.dialog.open(AddemployeeComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      data => console.log('Dialog output:', data)
    );

    dialogConfig.position = {
      top: '0',
      left: '1'
    };
  }

}





