
import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator, MatSort, MatSortable, MatTableDataSource, MatDialog, MatDialogConfig} from '@angular/material';
import { AddcommentComponent } from 'src/app/dialogs/addcomment/addcomment.component';
import {EmployeeTaggingData} from 'src/app/models/EmployeeTaggingData';
import { DataService } from 'src/app/services/data.service';
import {CurrentEmployee} from 'src/app/models/current-employee.model';
import {pendingEmployeeService} from 'src/app/services/pending-employee.service';
import { Observable } from 'rxjs/Observable';

/**
 * @title Table with pagination and sorting for displaying existing employees data
 */
@Component({
  selector: 'app-pending-employee',
  styleUrls: ['./pending-employee.component.css'],
  templateUrl: './pending-employee.component.html',
})

export class PendingEmployeeComponent implements  OnInit {
  constructor(public dialog: MatDialog, private dataService: DataService,private pendingEmpService:pendingEmployeeService
    ) { }
  ELEMENT_DATA: EmployeeTaggingData[];
  employeeData: EmployeeTaggingData[];
  currentEmployees: CurrentEmployee[];
  selected: CurrentEmployee[] = [];
  public roleData: any;
  isLeadership: boolean;
  // Initilize Department Class
  selectedValue: string;
   SelStatus = [
       {value: '0', display: 'Pending'},
       {value: '1', display: 'Approve'},
       {value: '2', display: 'Reject'},
       {value: '3', display: 'Tagging Completed'},
       {value: '4', display: 'Error'}
   ];
   comments = [
       {value: '0', display: 'Early Release - Scope Reduction'},
       {value: '1', display: 'Early Release - Skills Issue'},
       {value: '2', display: 'Early Release - Discipline Issue'},
       {value: '3', display: 'Early Release - Project Closure'},
       {value: '4', display: 'Extension - Role Extended'},
       {value: '5', display: 'Extension - New Opportunity'}
   ];


  dataSource: MatTableDataSource<EmployeeTaggingData>;
// tslint:disable-next-line: max-line-length
  displayedColumns: string[] = ['row_num', 'Account', 'Project', 'Serviceline', 'Resource', 'Grade', 'Skills', 'Startdate', 'Enddate',  'Newenddate','RequestedBy','ReasonForChange', 'Status', 'Comment','Confirm'];

// tslint:disable-next-line: member-ordering
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  getComment(element, event) {
    console.log(element, event.value);
    element.coment = event.value;
  }

  ngOnInit() {
    this.reloadData();
    this.getLoggedinUserRole();
  }

  reloadData()
  {
    this.pendingEmpService.getEMployeeForRMG().subscribe((response: EmployeeTaggingData[]) =>{
      this.employeeData = response;
      console.log('emp data', response);
      this.dataSource = new MatTableDataSource(this.employeeData);
      this.dataSource.sort=this.sort;
      this.dataSource.paginator = this.paginator;
    });

  }

  applyFilter(filterValue: string) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
      }

  onChange(event, element){
    // element.newenddate=event.value;
    element.coment = event;
    // this.selected.push(element);
    console.log(this.selected);
     }
  updateProjectResourceDetails(element)
  {

    if (element.status == "2" && element.coment==null) {
      alert('Comment cannot be empty for EmployeeId: ' + element.empid);
    }
    else{

    this.selected.push(element);
    console.log(element);
    this.pendingEmpService.updateProjectResourceDetails(this.selected).subscribe((response:CurrentEmployee[])=>{
      console.log(response);
       this.currentEmployees= response;
       this.dataSource = new MatTableDataSource(this.currentEmployees);
      this.reloadData();
      this.selected = [];
      });
    }
  }

  getLoggedinUserRole() {
    this.pendingEmpService.getLoggedinUserRole().subscribe((response) => {
      this.roleData = response;
      if(this.roleData.length>0)
      {
        if(this.roleData[0].role=="LEADERSHIP")
        this.isLeadership=true;
        console.log(this.isLeadership);
      }
  });
}

  openDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = this.ELEMENT_DATA;
    const dialogRef = this.dialog.open(AddcommentComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
        data => console.log('Dialog output:', data)
    );

    dialogConfig.position = {
      top: '0',
      left: '0'
    };
  }
}

export interface Food {
  value: string;
  display: string;
}
// export interface EmployeeDetails {
//   name: string;
//   position: number;
//   empid: number;
//   projectname: string;
//   projectcode: string;
//   grade: string;
//   serviceline: string;
//   skills: string;
//   startdate: string;
//   enddate: string;
//   newenddate: string;
//   actions: string;
//   comment: string;
// }
