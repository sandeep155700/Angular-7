import { Component, OnInit } from '@angular/core';
import {UserNameService} from '../../../services/user-name.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(public userNameService: UserNameService) { }
  userName;
  ngOnInit() {
    this.userName = this.userNameService.getName();
    console.log('header', this.userName)
  }

}
