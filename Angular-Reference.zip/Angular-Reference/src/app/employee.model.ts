export class mu
{
    muid: number;
    muname: string;
}
export class account
{
    accountid: number;
    accountname: string;
    muid: number;
}
export class project
{
    projectid: number;
    projectname: string;
    accountid: number;
}