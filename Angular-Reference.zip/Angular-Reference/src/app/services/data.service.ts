import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, throwError} from 'rxjs';
import {HttpClient, HttpHeaders, HttpResponse, HttpErrorResponse} from '@angular/common/http';
import {catchError, tap, retry} from 'rxjs/operators';
import {EmployeeTaggingData} from 'src/app/models/EmployeeTaggingData';
import { environment } from 'src/environments/environment';
import { stringify } from '@angular/compiler/src/util';





@Injectable({
  providedIn: 'root'
})

export class DataService {
  private BaseUrl=environment.apiUrl;
//   httpOptions = {
//     headers: new HttpHeaders({
// // tslint:disable-next-line: object-literal-key-quotes
//       'Accept': 'application/json',
//       'Content-Type': 'application/json',
//       'Access-Control-Allow-Origin': '*'
//     })
//   };

  
 // dataChange: BehaviorSubject<EmployeeTaggingData[]> = new BehaviorSubject<EmployeeTaggingData[]>([]);
  // Temporarily stores data from dialogs
  //dialogData: any;

  constructor(private httpClient: HttpClient) {}

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':'application/json',  
    })
    };
  // private readonly API_URL = 'https://localhost:44314/api';
  //private readonly API_URL = 'http://localhost:65006/api/GetEmployeeDetails/156393';
  // private readonly apiGetMUList = `${this.API_URL}/GetMUList`;
  // private readonly apiGetAccountsList = `${this.API_URL}/GetAccountsList`;
  // private readonly apiGetProjectsList = `${this.API_URL}/GetProjectsList`;
  // private readonly apiGetEmployeeList = `${this.API_URL}/GetEmployeeList`;
  // private readonly apiGetEmployeeDetails = `${this.API_URL}/GetEmployeeDetails`;

  // get data(): EmployeeTaggingData[] {
  //   return this.dataChange.value;
  // }
  public getEmployee(): any{
    var empData = this.httpClient.get(this.BaseUrl+"Employee/all");
    console.log("emp data",JSON.stringify(empData));
    return empData;
  

   
//   const empObservable = new Observable(observer => {
//     setTimeout(() => {
//         observer.next(this.httpClient.get(this.BaseUrl+"Employee/all"));
//     }, 1000);
// });
// return empObservable
  }

  // getDialogData() {
  //   return this.dialogData;
  // }

  // getEmployeeDetails(): void {
  //   this.httpClient.get<EmployeeTaggingData[]>(this.API_URL).subscribe(data => {
  //       this.dataChange.next(data);
  //       alert(JSON.stringify(data));
  //     },
  //     (error: HttpErrorResponse) => {
  //     console.log (error.name + ' ' + error.message);
  //     });
  // }

  //   getEmployeeDetails(): any {
  //    return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL).subscribe(data => {
  //       this.dataChange.next(data);
  //     },
  //     (error: HttpErrorResponse) => {
  //     console.log (error.name + ' ' + error.message);
  //     });
  // }

  // getEmployeeDetails(): any {
  //    return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL).subscribe(data => {
  //       this.dataChange.next(data);
  //       // alert(JSON.stringify(data));
  //     },
  //     (error: HttpErrorResponse) => {
  //     console.log (error.name + ' ' + error.message);
  //     });
  // }

//   getEmployeeDetails(): Observable<EmployeeTaggingData[]> {
//     return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL);
// }

//   getEmployeeDetails(): any {
//     return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL).subscribe(data => {
//        this.dataChange.next(data);
//        alert(data);
//      },
//      (error: HttpErrorResponse) => {
//      console.log (error.name + ' ' + error.message);
//      });
//  }

 // HttpClient API get() method => Fetch employee
// getEmployee(id): Observable<EmployeeTaggingData> {
//   return this.httpClient.get<EmployeeTaggingData>(this.API_URL + '/GetEmployeeDetails/' + id)
//   .pipe(
//   retry(1),
//   catchError(this.handleError)
//   );
// }

// getEmployee(id): Observable<EmployeeTaggingData[]> {
//   return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL + '/GetEmployeeDetails/' + id)
//   .pipe();
// }

  // get(name: string) {
  //   console.log(this.httpClient.get(`${this.GETEMPLOYEEAPI}/${name}`));
  //   return this.httpClient.get(`${this.GETEMPLOYEEAPI}/${name}`);
  // }


  // getEmployeeDetails()  {
  //   // alert(JSON.stringify(this.httpClient.get(this.API_URL, this.httpOptions)));
  //   // console.log(this.httpClient.get<EmployeeTaggingData[]>(this.API_URL + '/GetEmployeeList'));
  //   // alert(JSON.stringify(this.httpClient.get<EmployeeTaggingData[]>(this.API_URL + '/GetEmployeeList')));
  //   return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL, this.httpOptions).pipe(
  //   retry(1),
  //   catchError(this.handleError));

  //   // return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL, this.httpOptions ).pipe(tap(data => data),
  //   // catchError(this.handleError));
  // }

  // Error handling
  // handleError(error: any) {
  //   let errorMessage = '';
  //   if (error.error instanceof ErrorEvent) {
  // // Get client-side error
  //   errorMessage = error.error.message;
  //   } else {
  //   // Get server-side error
  //   errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
  //   }
  //   window.alert(errorMessage);
  //   return throwError(errorMessage);
  // }





  // getEmployeeDetails(): Observable<EmployeeTaggingData[]> {
  //   console.log(this.httpClient.get<EmployeeTaggingData[]>(this.GETEMPLOYEEAPI));
  //   alert(JSON.stringify(this.httpClient.get<EmployeeTaggingData[]>(this.API_URL + '/GetEmployeeList')));
  //   return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL + '/GetEmployeeList');
  // }

  // dataChange: BehaviorSubject<EmployeeTaggingData[]> = new BehaviorSubject<EmployeeTaggingData[]>([]);
  // Temporarily stores data from dialogs
  // dialogData: any;

  // getEmployeeDetails(): Observable<EmployeeTaggingData[]> {
  //   return this.httpClient.get<EmployeeTaggingData[]>(this.API_URL);
  // }

  // get data(): EmployeeTaggingData[] {
  //   return this.dataChange.value;
  // }

  // getDialogData() {
  //   return this.dialogData;
  // }

  // /** CRUD METHODS */
  // getAllEmployee(): void {
  //   this.httpClient.get<EmployeeTaggingData[]>(this.API_URL).subscribe(data => {
  //       this.dataChange.next(data);
  //     },
  //     (error: HttpErrorResponse) => {
  //     console.log (error.name + ' ' + error.message);
  //     });
  // }

  // // DEMO ONLY, you can find working methods below
  // addEmloyee(employee: EmployeeTaggingData): void {
  //   this.dialogData = employee;
  // }

  // updateEmployee(employee: EmployeeTaggingData): void {
  //   this.dialogData = employee;
  // }

  // deleteEmployee(id: number): void {
  //   console.log(id);
  // }
}



/* REAL LIFE CRUD Methods I've used in my projects. ToasterService uses Material Toasts for displaying messages:

    // ADD, POST METHOD
    addItem(kanbanItem: KanbanItem): void {
    this.httpClient.post(this.API_URL, kanbanItem).subscribe(data => {
      this.dialogData = kanbanItem;
      this.toasterService.showToaster('Successfully added', 3000);
      },
      (err: HttpErrorResponse) => {
      this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
    });
   }

    // UPDATE, PUT METHOD
     updateItem(kanbanItem: KanbanItem): void {
    this.httpClient.put(this.API_URL + kanbanItem.id, kanbanItem).subscribe(data => {
        this.dialogData = kanbanItem;
        this.toasterService.showToaster('Successfully edited', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }

  // DELETE METHOD
  deleteItem(id: number): void {
    this.httpClient.delete(this.API_URL + id).subscribe(data => {
      console.log(data['']);
        this.toasterService.showToaster('Successfully deleted', 3000);
      },
      (err: HttpErrorResponse) => {
        this.toasterService.showToaster('Error occurred. Details: ' + err.name + ' ' + err.message, 8000);
      }
    );
  }
*/




