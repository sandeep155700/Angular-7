import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {EmployeeTaggingData} from 'src/app/models/EmployeeTaggingData';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs/Observable';
import { UserNameService } from '../services/user-name.service';


@Injectable({
  providedIn: 'root'
})
export class currentEmployeeService {
    private BaseUrl=environment.apiUrl;

    constructor(private http: HttpClient,public userNameService: UserNameService) {}

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',
        'Authorization':this.userNameService.getUserId()
      })
      };

      getLoggedinUserRole(){
        return this.http.get(this.BaseUrl+'GetLoggedinUserRole/'+this.userNameService.getUserName());
        }

      MU(){
        return this.http.get(this.BaseUrl+'GetMUList',this.httpOptions);
        }

        accounts(muId){
        return this.http.get(this.BaseUrl+'GetAccountsList/'+ muId,this.httpOptions);
        }

        projects(muId,accountId){

        return this.http.get(this.BaseUrl+'GetProjectsList/'+ muId+'/'+accountId,this.httpOptions);
        }

      currentEmployees():Observable<EmployeeTaggingData[]>{
          return this.http.get<EmployeeTaggingData[]>(this.BaseUrl+ 'GetEmployeeTaggingDetailsList',this.httpOptions);
      }
      getCurrentEmpsRelatedToProject(muId,accountId,projectId){
        return this.http.get(this.BaseUrl+ 'GetProjectResourceDetailsList/'+muId+'/'+accountId+'/'+ projectId,this.httpOptions);
      }
      insertProjectResourceDetails(projectResourceDetails){
        return this.http.post(this.BaseUrl+ 'PostProjectResourceDetails', projectResourceDetails,this.httpOptions);
      }

    }
