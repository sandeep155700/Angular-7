import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ApacRRMLogin} from 'src/app/models/ApacLogin';
import { environment } from 'src/environments/environment';
import { UserNameService } from '../services/user-name.service';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
    private BaseUrl=environment.apiUrl;

    constructor(private http: HttpClient,public userNameService: UserNameService) {}

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',
      })
      };

      getFirstTimelogin(userName){
        return this.http.get(this.BaseUrl+'GetFirstTimelogin/'+userName);
        }

        getAuthenticateUser(userName,password){
          return this.http.get(this.BaseUrl+'GetAuthenticateUser/'+userName+'/'+password);
          }

          setNewPassword(userName,password){
            return this.http.get(this.BaseUrl+'UpdateNewPassword/'+this.userNameService.getUserId()+'/'+userName+'/'+password);
            }
    }
