import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ApacRRMRoleMaster} from 'src/app/models/ApacRRMRoleMaster';
import { environment } from 'src/environments/environment';
import { UserNameService } from '../services/user-name.service';


@Injectable({
  providedIn: 'root'
})
export class RoleMasterService {
    private BaseUrl=environment.apiUrl;

    constructor(private http: HttpClient,public userNameService: UserNameService) {}

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':'application/json',
      })
      };

      getLoggedinUserRole(){
        return this.http.get(this.BaseUrl+'GetLoggedinUserRole/'+this.userNameService.getUserName());
        }
    }
