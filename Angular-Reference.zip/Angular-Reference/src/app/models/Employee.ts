export interface Employee {
// tslint:disable-next-line: variable-name
//   row_num: string;
//   empid: string;
//   name: string;
//   projectname: string;
//   projectcode: string;
//   grade: string;
//   serviceline: string;
//   skills: string;
// //  status: string;
//   startdate: string;
//   enddate: string;
//   newenddate: string;
//   actions: string;
//   comment: string;

id: number;
name: string;
empid: number;
grade: string;
projectName:string;
projectCode:string;
serviceLine: string;
skills: string;
status: string;
startDate: Date;
endDate: Date;

}

