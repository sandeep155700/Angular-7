export class ApacRRMLogin {
  userid: string;
  username: string;
  password: string;
  newPassword: string;
  flag: string;
}
