export interface ApacRRMRoleMaster {
// tslint:disable-next-line: variable-name
roleid: string;
role: string;
empid: string;
userid:string;
}
