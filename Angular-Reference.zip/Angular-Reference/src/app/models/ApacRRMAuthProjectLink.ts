export class ApacRRMAuthProjectLink {
    authprojectid: number;
    authid: string;
    projectcode: string;
}
