// tslint:disable-next-line: eofline
export const ROOT_URL = 'http://localhost:42333/api/';