export interface EmployeeTaggingData {
    ROW_NUM: number;
    EMPLOYEE: string;
    Account: string;
    EMPName: string;
    EMPID: string;
    GRADE?: any;
    SERVICELINE: string;
    SKILLS?: any;
    STATUS?: any;
    STARTDATE: string;
    ENDDATE: string;
    NEWENDDATE?: any;
    PROJECTCODE: string;
    COMENT: string;
    REASONFORCHANGE: string;
}
