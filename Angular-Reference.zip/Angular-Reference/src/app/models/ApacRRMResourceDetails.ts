export class ApacRRMResourceDetails {
    resourceid: number;
    projectcode: string;
    employeeid: string;
    enddate: Date = new Date();
    newenddate: Date = new Date();
    status: string;
    statuschgby: string;
    statuschgon: Date = new Date();
    newenddtchgby: string;
    newenddtchgon: Date = new Date();
}
