export class ApacRRMMU {
    muid: number;
    muname: string;
    status: string;
}
