export class EmployeeSkillsData {
    names: string;
    pus: string;
    countrys: string;
    sbus: string;
    offices: string;
    categorys: string;
    skills: string;
    skillcategorys: string;
    proficiencys: string;
    experiences: string;
    recencys: string;
    primarys: string;
    updatedattrs: string;
    lastvalues: string;
    lastupdates: string;
    updatedbys: string;
    month: string;
    year: string;
    lastupdateddate: string;
    categorizationskill: string;
    employeenos: string;
    skillfamilys: string;
    skillgroups: string;
}
