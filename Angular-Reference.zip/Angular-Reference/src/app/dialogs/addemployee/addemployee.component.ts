import { Component, OnInit, Inject } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';
import {Employee} from 'src/app/models/Employee';
import { DataService } from 'src/app/services/data.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogConfig} from '@angular/material';


@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  form: FormGroup;
  description: string;
  employeeData: Employee[];
  dataSource: MatTableDataSource<Employee>;

  constructor(
      private fb: FormBuilder,
      private dialogRef: MatDialogRef<AddemployeeComponent>,
      private dataService: DataService,private employeeService:DataService,
      @Inject(MAT_DIALOG_DATA) data
      ) {
      this.description = data.description;
  }

  ngOnInit() {
    this.reloadData();
  }
  reloadData()
  {
    this.employeeService.getEmployee().subscribe((response: Employee[]) =>{
      this.employeeData = response;
      console.log("emp data",response)
      this.dataSource = new MatTableDataSource(this.employeeData);
      
    });

  }
  save() {
    this.dialogRef.close(this.form.value);
  }

  close() {
      this.dialogRef.close();
  }

}
