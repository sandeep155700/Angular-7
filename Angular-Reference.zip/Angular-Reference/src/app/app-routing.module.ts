import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { NotAuthorizedComponent } from './components/not-authorized/not-authorized.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  //{ path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '', component: LoginComponent },
  {
    path: 'home', component: HomeComponent, pathMatch: 'full'
    // children: [
    //   { path: 'notAuth', component: NotAuthorizedComponent }
    // ]
  },
  { path: 'notAuth', component: NotAuthorizedComponent , pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{
    //onSameUrlNavigation:'reload'
     useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
